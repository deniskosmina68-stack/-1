import math
import statistics

def show_math():
    numbers = [4, 8, 10, 6]
    print("\n[Вбудовані: math, statistics]")
    print("Квадратний корінь із 81:", math.sqrt(81))
    print("Середнє значення:", statistics.mean(numbers))
