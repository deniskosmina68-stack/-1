# Лабораторна робота № 4 — Бібліотеки Python

## Що робить проєкт
Програма демонструє роботу з датою, математикою, текстом, випадковими даними, JSON, URL, зображеннями, таблицями, кольоровим текстом, прогрес-баром, QR-кодом і створенням коротких назв.

## Встановлення
```bash
python -m pip install -r requirements.txt
```

## Запуск
```bash
python main.py
```

## Бібліотеки
**Вбудовані модулі (понад 5):** `platform`, `sys`, `datetime`, `math`, `statistics`, `textwrap`, `re`, `pathlib`, `urllib.parse`, `io`, `time`.

**10 сторонніх бібліотек:** `Faker`, `orjson`, `humanize`, `validators`, `Pillow`, `tabulate`, `colorama`, `tqdm`, `qrcode`, `python-slugify`.
