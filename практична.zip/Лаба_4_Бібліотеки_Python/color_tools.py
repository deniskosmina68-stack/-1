from colorama import Fore, Style, init

def show_color():
    init(autoreset=True)
    print("\n[Стороння: colorama]")
    print(Fore.GREEN + "Приклад кольорового тексту" + Style.RESET_ALL)
