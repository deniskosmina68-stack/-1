import orjson

def show_json():
    data = {"магазин": "МініМаркет", "товарів": 3, "працює": True}
    print("\n[Стороння: orjson]")
    print("JSON:", orjson.dumps(data).decode("utf-8"))
