from app_info import show_info
from date_tools import show_date
from math_tools import show_math
from text_tools import show_text
from random_tools import show_random
from json_tools import show_json
from path_tools import show_path
from web_tools import show_url
from image_tools import show_image_info
from table_tools import show_table
from color_tools import show_color
from progress_tools import show_progress
from qr_tools import show_qr
from slug_tools import show_slug

def main():
    print("=== Демонстрація бібліотек Python ===")
    show_info(); show_date(); show_math(); show_text()
    show_random(); show_json(); show_path(); show_url()
    show_image_info(); show_table(); show_color(); show_progress()
    show_qr(); show_slug()

if __name__ == "__main__":
    main()
