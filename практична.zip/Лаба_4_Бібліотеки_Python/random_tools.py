from faker import Faker

def show_random():
    fake = Faker("uk_UA")
    print("\n[Стороння: Faker]")
    print("Приклад вигаданого імені:", fake.name())
