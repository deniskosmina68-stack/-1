from urllib.parse import urlparse
import validators

def show_url():
    url = "https://example.com/shop"
    print("\n[Стороння: validators; вбудована: urllib.parse]")
    print("URL правильний:", validators.url(url))
    print("Домен:", urlparse(url).netloc)
