import textwrap
import re

def show_text():
    phrase = "Python допомагає автоматизувати прості завдання"
    print("\n[Вбудовані: textwrap, re]")
    print("Текст:", textwrap.fill(phrase, width=45))
    print("Кількість слів:", len(re.findall(r"\w+", phrase, flags=re.UNICODE)))
