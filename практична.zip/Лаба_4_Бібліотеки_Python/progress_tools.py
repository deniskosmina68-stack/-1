from tqdm import tqdm
import time

def show_progress():
    print("\n[Стороння: tqdm]")
    for _ in tqdm(range(5), desc="Демонстрація", leave=False):
        time.sleep(0.05)
