import qrcode

def show_qr():
    qr = qrcode.QRCode(box_size=2, border=1)
    qr.add_data("https://example.com")
    qr.make(fit=True)
    qr.make_image(fill_color="black", back_color="white").save("demo_qr.png")
    print("\n[Стороння: qrcode]")
    print("QR-код збережено у файлі demo_qr.png")
