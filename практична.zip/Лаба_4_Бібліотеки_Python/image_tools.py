from PIL import Image
from io import BytesIO

def show_image_info():
    image = Image.new("RGB", (120, 80), color="white")
    buffer = BytesIO()
    image.save(buffer, format="PNG")
    print("\n[Стороння: Pillow]")
    print("Розмір тестового зображення:", image.size)
    print("Розмір PNG у байтах:", len(buffer.getvalue()))
