import platform
import sys

def show_info():
    print("\n[Вбудовані: platform, sys]")
    print("Версія Python:", platform.python_version())
    print("Назва програми:", sys.argv[0])
