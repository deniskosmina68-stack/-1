from tabulate import tabulate

def show_table():
    rows = [["Хліб", "25.50 грн"], ["Молоко", "42.00 грн"], ["Яблука", "35.20 грн"]]
    print("\n[Стороння: tabulate]")
    print(tabulate(rows, headers=["Товар", "Ціна"], tablefmt="simple"))
