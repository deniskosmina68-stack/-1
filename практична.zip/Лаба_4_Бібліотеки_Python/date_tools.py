from datetime import datetime, date

def show_date():
    print("\n[Вбудована: datetime]")
    print("Поточна дата й час:", datetime.now().strftime("%d.%m.%Y %H:%M"))
    print("Рік:", date.today().year)
