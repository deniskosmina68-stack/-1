from pathlib import Path
import humanize

def show_path():
    sample = Path("main.py")
    print("\n[Стороння: humanize; вбудована: pathlib]")
    print("Назва файлу:", sample.name)
    print("Приклад розміру:", humanize.naturalsize(15360))
