from slugify import slugify

def show_slug():
    print("\n[Стороння: python-slugify]")
    print("Короткий URL:", slugify("Мій перший проєкт Python", allow_unicode=True))
